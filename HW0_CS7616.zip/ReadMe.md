# CS 7616
## HW 0
#### Student information: Anisha Gartia
#### GTID : 903136557

Language  of coding - Matlab
<br>
Files included: <br>   
    1. csv.winedata.csv - This is the winedata on which we have performed analysis. Data is imported from this file.<br>
    2. attributenames.txt - This is a list of all the 13 attributes of wine. Data is imported from this file. <br>
    3. HW0.m - This is the matlab code file. <br>
    4. HW0.ipynb - This is the Jupyter notebook which has the executable cells containing matlab codes, and resulting plot. <br>
	5. HW0.pdf - This is a pdf version of the entire project, including introduction, code, and plots.
	6. HW0.html - html generated using 'download as html' option in jupyter notebook.
	
webaddress of github repository: https://github.com/anishagartia/HW0_CS7616.git	


